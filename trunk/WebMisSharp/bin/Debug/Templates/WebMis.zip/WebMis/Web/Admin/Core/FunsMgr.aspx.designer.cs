﻿//------------------------------------------------------------------------------
// <自动生成>
//     此代码由工具生成。
//
//     对此文件的更改可能会导致不正确的行为，并且如果
//     重新生成代码，这些更改将会丢失。 
// </自动生成>
//------------------------------------------------------------------------------

namespace Web.Admin {
    
    
    public partial class FunsMgr {
        
        /// <summary>
        /// MainForm 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm MainForm;
        
        /// <summary>
        /// Main_ResourceManager 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.ResourceManager Main_ResourceManager;
        
        /// <summary>
        /// WMS_USERFUN_MainStore 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Store WMS_USERFUN_MainStore;
        
        /// <summary>
        /// MainViewPort 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Viewport MainViewPort;
        
        /// <summary>
        /// WMS_USERFUN_Grid 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.GridPanel WMS_USERFUN_Grid;
        
        /// <summary>
        /// MainToolBar 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Toolbar MainToolBar;
        
        /// <summary>
        /// WMS_USERFUN_Filter 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.GridFilters WMS_USERFUN_Filter;
        
        /// <summary>
        /// PagingToolBar 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.PagingToolbar PagingToolBar;
        
        /// <summary>
        /// WMS_USERFUN_Win 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Window WMS_USERFUN_Win;
        
        /// <summary>
        /// WMS_USERFUN_MainForm 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.FormPanel WMS_USERFUN_MainForm;
        
        /// <summary>
        /// NFfunid 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.NumberField NFfunid;
        
        /// <summary>
        /// Txtfunno 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.TextField Txtfunno;
        
        /// <summary>
        /// Txtfunname 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.TextField Txtfunname;
        
        /// <summary>
        /// NFfatherid 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.NumberField NFfatherid;
        
        /// <summary>
        /// Hid 控件。
        /// </summary>
        /// <remarks>
        /// 自动生成的字段。
        /// 若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
        /// </remarks>
        protected global::Ext.Net.Hidden Hid;
    }
}
