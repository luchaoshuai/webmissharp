﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class WMS_AUTHORITY
    {
        public WMS_AUTHORITY()
        { }
        public string funno { get; set; }
    }
}
